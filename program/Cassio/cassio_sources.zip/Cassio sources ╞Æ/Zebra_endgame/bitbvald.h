/*
   File:          bitbvald.h

   Created:       November 22, 1999
   
   Modified:      April 26, 2000

   Authors:       Gunnar Andersson (gunnar@radagast.se)

   Contents:
*/



#ifndef BITBVALD_H
#define BITBVALD_H



#include "bitboard.h"



extern int (*ValidOneEmpty_bitboard[89])(const BitBoard my_bits);



#endif  /* BITBVALD_H */
